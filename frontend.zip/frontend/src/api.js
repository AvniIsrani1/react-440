// src/api.js
import axios from 'axios';

// 1) Base URL: set once, use everywhere
// - Prefer env var so you can switch dev/prod without code changes.
// - Example dev: http://localhost:3000
const API_BASE = process.env.REACT_APP_API_BASE || 'http://localhost:3000';

// 2) Create a pre-configured axios instance
const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' },
  // timeout: 10000, // (optional) 10s timeout
});

// 3) (Optional) Attach interceptors for auth & errors
// Example: read token from localStorage and attach to every request
// api.interceptors.request.use((config) => {
//   const token = localStorage.getItem('token');
//   if (token) config.headers.Authorization = `Bearer ${token}`;
//   return config;
// });

// api.interceptors.response.use(
//   (res) => res,
//   (err) => {
//     // Centralize certain error behaviors (e.g., redirect on 401)
//     if (err?.response?.status === 401) {
//       // e.g., window.location = '/login';
//     }
//     return Promise.reject(err);
//   }
// );

export default api;
