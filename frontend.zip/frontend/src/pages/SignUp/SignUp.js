// src/pages/SignUp.js
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api'; // if you created api.js earlier; otherwise swap to fetch

import './SignUp.css';

export default function SignUp() {
  const [form, setForm] = useState({
    username: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
  });
  const [msg, setMsg] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setMsg('');
    if (form.password !== form.confirmPassword) {
      setMsg('Passwords do not match');
      return;
    }
    setSubmitting(true);
    try {
      // Hit your NestJS endpoint: POST /auth/register
      await api.post('/auth/register', {
        username: form.username.trim(),
        password: form.password,
        firstName: form.firstName.trim(),
        lastName: form.lastName.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
      });
      setMsg('✅ Registered! You can now sign in.');
      setForm({
        username: '',
        password: '',
        confirmPassword: '',
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
      });
    } catch (err) {
      const server = err?.response?.data;
      const errMsg = Array.isArray(server?.message)
        ? server.message.join(', ')
        : server?.message || server?.error || err.message;
      setMsg(errMsg);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-root">
      {/* LEFT: Card */}
      <section className="auth-card" aria-label="Sign up form">
        <div className="brand">
          <div className="brand-mark" aria-hidden="true"></div>
          <span>Template<br/>Design</span>
        </div>

        <div className="avatar" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="56" height="56" role="img" aria-label="User">
            <circle cx="12" cy="8" r="4" fill="currentColor" opacity="0.25"/>
            <path d="M4 20a8 8 0 0 1 16 0" fill="currentColor" opacity="0.25"/>
          </svg>
        </div>

        <form onSubmit={submit} className="form">
          <div className="field">
            <span className="icon" aria-hidden="true">
              <svg viewBox="0 0 24 24"><path d="M4 12a8 8 0 1 1 16 0v6H4z"/><circle cx="12" cy="10" r="3"/></svg>
            </span>
            <input
              name="username" placeholder="Username" value={form.username} onChange={onChange} required
              autoComplete="username"
            />
          </div>

          <div className="grid-two">
            <div className="field">
              <input name="firstName" placeholder="First name" value={form.firstName} onChange={onChange} required/>
            </div>
            <div className="field">
              <input name="lastName" placeholder="Last name" value={form.lastName} onChange={onChange} required/>
            </div>
          </div>

          <div className="field">
            <input type="email" name="email" placeholder="Email" value={form.email} onChange={onChange} required/>
          </div>

          <div className="field">
            <input name="phone" placeholder="Phone" value={form.phone} onChange={onChange} required/>
          </div>

          <div className="field">
            <span className="icon" aria-hidden="true">
              <svg viewBox="0 0 24 24"><path d="M6 10V7a6 6 0 1 1 12 0v3"/><rect x="4" y="10" width="16" height="10" rx="2"/></svg>
            </span>
            <input type="password" name="password" placeholder="Password" value={form.password} onChange={onChange} required autoComplete="new-password"/>
          </div>

          <div className="field">
            <input type="password" name="confirmPassword" placeholder="Confirm password" value={form.confirmPassword} onChange={onChange} required autoComplete="new-password"/>
          </div>

          <div className="actions">
            <label className="remember">
              <input type="checkbox" /> Remember me
            </label>
            <button className="btn-primary" type="submit" disabled={submitting}>
              {submitting ? 'Creating...' : 'Create account'}
            </button>
          </div>

          {msg && <p className={`msg ${msg.startsWith('✅') ? 'ok' : 'err'}`}>{msg}</p>}

          <p className="hint">
            Already a member? <Link to="/login">Sign in</Link>
          </p>
        </form>
      </section>

      {/* RIGHT: Hero */}
      <section className="hero" aria-label="Welcome panel">
        <header className="hero-nav">
          <nav>
            <a href="#about">ABOUT</a>
            <a href="#download">DOWNLOAD</a>
            <a href="#pricing">PRICING</a>
            <a href="#contact">CONTACT</a>
          </nav>
          <div className="hero-cta">
            <Link to="/login" className="btn-ghost">SIGN IN</Link>
            <button className="hamburger" aria-label="Menu" aria-expanded="false">
              <span></span><span></span><span></span>
            </button>
          </div>
        </header>

        <div className="hero-pane">
          <h1>Welcome.</h1>
          <p>
            Create an account to access the platform. Your profile will help personalize your experience.
          </p>
          <p className="tiny">New here? You’re in the right place.</p>
        </div>
      </section>
    </div>
  );
}
